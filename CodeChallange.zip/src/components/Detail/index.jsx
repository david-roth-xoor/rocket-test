import { Container } from "@mui/material"
import { Axios } from "axios";
import { useEffect } from "react";
import { useParams } from 'react-router-dom';

const Details = ()=> {
  let { id } = useParams();

  return <Container>
    {}
  </Container>
}

export default Details;
