const Favourite = () => {
  return <div>

  </div>
}

export default Favourite;